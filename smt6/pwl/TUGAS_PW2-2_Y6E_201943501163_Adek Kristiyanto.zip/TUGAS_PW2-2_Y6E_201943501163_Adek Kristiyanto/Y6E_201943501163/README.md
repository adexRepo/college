Note
RUNNING DI SATU FILE SAJA CUKUP: 

0_index.php

Nama    : Adek Kristiyanto
NPM     : 201943501163
KELAS   : Y6E
GitHub  : @adexRepo

kalo error bisa clone di github saya