<!-- // TIPE DATA BOOLEAN

1. Tipe data boolean adalah tipe data yang paling sederhana di PHP
2. Tipe data boolean adalah tipe data dengan nilai kebenaran (benar atau salah)
3. Nilai benar direpresentasikan dengan true (case insensitive)
4. Nilai salah direpresentasikan dengan false (case insensitive) -->


<?php
// NOTE var_dumb() >> adalah fungsi yang bisa menampilkan tipe data dan isi dari variabel

echo "Benar : ";
var_dump(trUe);
echo "<br/>";    echo "<br/>";


echo "Benar : ";
var_dump(falsE);